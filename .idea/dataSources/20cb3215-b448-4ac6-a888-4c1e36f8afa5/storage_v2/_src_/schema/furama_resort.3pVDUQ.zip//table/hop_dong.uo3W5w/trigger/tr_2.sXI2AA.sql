create definer = root@localhost trigger tr_2
    after update
    on hop_dong
    for each row
begin
        if datediff(new.ngay_ket_thuc,old.ngay_lam_hd)<2 then
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ngày kết thúc phải sau ngày làm hợp đồng ít nhất 2 ngày';
        end if;
    end;

