create definer = root@localhost view v_nhan_vien as
select `nv`.`id_nv`       AS `id_nv`,
       `nv`.`ten_nv`      AS `ten_nv`,
       `nv`.`id_vi_tri`   AS `id_vi_tri`,
       `nv`.`id_bo_phan`  AS `id_bo_phan`,
       `nv`.`id_trinh_do` AS `id_trinh_do`,
       `nv`.`ngay_sinh`   AS `ngay_sinh`,
       `nv`.`so_cmnd`     AS `so_cmnd`,
       `nv`.`luong`       AS `luong`,
       `nv`.`sdt`         AS `sdt`,
       `nv`.`email`       AS `email`,
       `nv`.`dia_chi`     AS `dia_chi`
from (`furama_resort`.`nhan_vien` `nv`
         join `furama_resort`.`hop_dong` `hd` on ((`nv`.`id_nv` = `hd`.`id_nv`)))
where ((`nv`.`dia_chi` = 'Da Nang') and (`hd`.`ngay_lam_hd` = '2021-02-11'));

