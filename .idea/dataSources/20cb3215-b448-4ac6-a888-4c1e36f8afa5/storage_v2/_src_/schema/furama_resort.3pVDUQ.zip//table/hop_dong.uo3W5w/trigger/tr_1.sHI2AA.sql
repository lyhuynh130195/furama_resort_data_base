create definer = root@localhost trigger tr_1
    after delete
    on hop_dong
    for each row
begin
        set @s=(select count(id_hop_dong)  as so_hop_dong_con_lai from hop_dong);
    end;

