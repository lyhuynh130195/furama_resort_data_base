create
    definer = root@localhost function func_2(id_khach_hang int) returns int
begin
    declare thoi_gian int;
    set thoi_gian =(select max(thoi_gian_hop_dong2) from thoi_gian_hop_dong);
    return thoi_gian;
end;

