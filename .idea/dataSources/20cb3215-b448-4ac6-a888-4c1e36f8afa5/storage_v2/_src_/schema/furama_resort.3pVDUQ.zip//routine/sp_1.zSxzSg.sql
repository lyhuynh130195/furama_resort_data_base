create
    definer = root@localhost procedure sp_1(IN id int)
begin
    delete from khach_hang
        where khach_hang.id_khach_hang=id;
end;

