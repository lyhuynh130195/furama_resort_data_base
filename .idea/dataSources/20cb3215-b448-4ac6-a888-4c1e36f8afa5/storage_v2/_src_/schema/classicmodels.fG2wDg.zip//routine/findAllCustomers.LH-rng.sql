create
    definer = root@localhost procedure findAllCustomers()
BEGIN

SELECT*FROM customers;

END;

