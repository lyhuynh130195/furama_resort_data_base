create definer = root@localhost view customers_view as
select `classicmodels`.`customers`.`customerNumber`   AS `customerNumber`,
       `classicmodels`.`customers`.`customerName`     AS `customerName`,
       `classicmodels`.`customers`.`contactFirstName` AS `contactFirstName`,
       `classicmodels`.`customers`.`contactLastName`  AS `contactLastName`,
       `classicmodels`.`customers`.`phone`            AS `phone`
from `classicmodels`.`customers`
where (`classicmodels`.`customers`.`city` = 'Nantes');

