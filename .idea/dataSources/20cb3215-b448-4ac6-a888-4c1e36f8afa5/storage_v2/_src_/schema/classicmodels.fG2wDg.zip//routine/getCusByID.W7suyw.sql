create
    definer = root@localhost procedure getCusByID(IN cusNum int)
BEGIN
SELECT * FROM customers WHERE customerNumber =cusNum;
END;

